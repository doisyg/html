var SvgPanZoom = require("./svg-pan-zoom.js");

module.exports = SvgPanZoom;
