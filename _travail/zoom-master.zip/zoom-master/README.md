# Image Zoom

- allows user to zoom an image

## SUPPORTED ACTIONS

- doubleclick
- mousemove
- mousewheel
- doubletap
- touchmove
- pinch
